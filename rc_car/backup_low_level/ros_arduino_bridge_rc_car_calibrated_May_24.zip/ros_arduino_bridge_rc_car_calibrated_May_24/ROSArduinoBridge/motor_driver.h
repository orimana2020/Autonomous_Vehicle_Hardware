

Servo drive_motor;
Servo steering_motor;

void initMotorController();
void SetSteeringAngle(int steering_angle_command);
void SetDriveMotorSpeed(int drive_motor_control_command);
void SetMotorsCommands(int drive_motor_control_command, int steering_angle_command);
