/* PID setpoint info For a Motor */
typedef struct {
  float e;
  float dedt;
  float eprev;
  float eintegral;
  int output;  
  float target_encoder_rev_per_sec;
  float encoder_rev_per_sec;
  float encoder;
  float prev_encoder;

  /* Using previous input (PrevInput) instead of PrevError to avoid derivative kick,
  * Using integrated term (ITerm) instead of integrated error (Ierror) to allow tuning changes,*/
}
SetPointInfo;

SetPointInfo drive_motor_PID;
SetPointInfo steering_motor_PID;
float deltaT_sec;

/* PID Parameters */
float kp = 0.22;
float kd = 0.0;
float ki = 0.05;

unsigned char moving = 0; // is the base in motion?

void resetPID(){
  drive_motor_PID.e = 0.0;
  drive_motor_PID.dedt= 0.0;
  drive_motor_PID.eprev=0.0;
  drive_motor_PID.eintegral=0.0;
  drive_motor_PID.output= 0;  
  drive_motor_PID.target_encoder_rev_per_sec=0.0;
  drive_motor_PID.encoder_rev_per_sec=0.0;
  drive_motor_PID.encoder = readEncoder();
  drive_motor_PID.prev_encoder = drive_motor_PID.encoder;

  steering_motor_PID.output = 0;
  }

/* PID routine to compute the next motor commands */
void doPID(SetPointInfo * p) {

  p->encoder = readEncoder();
  deltaT_sec = deltaT_pid_ms / 1000.0;

  p->encoder_rev_per_sec = (p->encoder - p->prev_encoder) / deltaT_sec;

  p->prev_encoder = p->encoder;
  
  // error
  p->e =  p->target_encoder_rev_per_sec - p->encoder_rev_per_sec ;

  // derivative
  p->dedt = (p->e - p->eprev) / deltaT_sec;

  // control signal
  p->output = kp*p->e + kd*p->dedt + ki*p->eintegral;

  // integral
  p->eintegral = p->eintegral + p->e * deltaT_sec;

  // store previous error
  p->eprev = p->e;
  }


void updatePID() {
  /* If we're not moving there is nothing more to do */
  if (!moving){
    if (drive_motor_PID.output != 0){
      resetPID();
      }
    return;
  }

  /* Compute PID update for each motor */
  doPID(&drive_motor_PID);

  /* Set the motor speeds accordingly */
  SetMotorsCommands(drive_motor_PID.output, steering_motor_PID.output);
}

